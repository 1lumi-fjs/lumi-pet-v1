# 露米桌宠 v0.2

Android 悬浮桌宠原型。通过 GitHub Actions 云端编译。
