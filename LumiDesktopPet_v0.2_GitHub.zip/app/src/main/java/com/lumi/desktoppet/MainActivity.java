package com.lumi.desktoppet;
import android.app.*;import android.os.*;import android.content.*;import android.net.*;import android.provider.Settings;import android.view.*;import android.widget.*;
public class MainActivity extends Activity{
 int d(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(d(24),d(40),d(24),d(24));
 TextView t=new TextView(this);t.setText("🎀 露米桌宠");t.setTextSize(28);l.addView(t);
 TextView i=new TextView(this);i.setText("白发 · 淡紫色眼睛 · 尖耳 · 双角 · 细长尾巴\n\n请先开启悬浮窗权限。");i.setTextSize(17);i.setPadding(0,d(20),0,d(20));l.addView(i);
 Button p=new Button(this);p.setText("① 开启悬浮窗权限");p.setOnClickListener(v->{startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));});l.addView(p);
 Button s=new Button(this);s.setText("② 启动露米");s.setOnClickListener(v->{if(Settings.canDrawOverlays(this))startService(new Intent(this,PetService.class));else p.performClick();});l.addView(s);
 Button x=new Button(this);x.setText("③ 收起露米");x.setOnClickListener(v->stopService(new Intent(this,PetService.class)));l.addView(x);setContentView(l);}
}
