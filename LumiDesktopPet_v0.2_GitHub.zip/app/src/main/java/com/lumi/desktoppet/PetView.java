package com.lumi.desktoppet;
import android.content.*;import android.graphics.*;import android.view.*;
public class PetView extends View{
 Paint p=new Paint(1);int mood=0;long start=System.currentTimeMillis();public PetView(Context c){super(c);}public void nextMood(){mood=(mood+1)%3;invalidate();}
 protected void onDraw(Canvas c){float w=getWidth(),h=getHeight(),t=(System.currentTimeMillis()-start)/1000f,b=(float)Math.sin(t*2)*4;c.save();c.translate(0,b);
 p.setColor(0x22000000);c.drawOval(new RectF(w*.16f,h*.83f,w*.84f,h*.93f),p);
 p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(9);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(0xFF8E7CC3);Path tail=new Path();tail.moveTo(w*.69f,h*.62f);tail.cubicTo(w*.98f,h*.57f,w*.98f,h*.80f,w*.75f,h*.78f);c.drawPath(tail,p);p.setStyle(Paint.Style.FILL);
 p.setColor(0xFFEDE7F7);Path dr=new Path();dr.moveTo(w*.31f,h*.51f);dr.lineTo(w*.69f,h*.51f);dr.lineTo(w*.88f,h*.86f);dr.lineTo(w*.12f,h*.86f);dr.close();c.drawPath(dr,p);
 p.setColor(Color.WHITE);c.drawRoundRect(new RectF(w*.19f,h*.17f,w*.81f,h*.66f),55,55,p);
 p.setColor(0xFFEFEAF8);Path e=new Path();e.moveTo(w*.23f,h*.28f);e.lineTo(w*.07f,h*.10f);e.lineTo(w*.20f,h*.42f);e.close();c.drawPath(e,p);e=new Path();e.moveTo(w*.77f,h*.28f);e.lineTo(w*.93f,h*.10f);e.lineTo(w*.80f,h*.42f);e.close();c.drawPath(e,p);
 p.setColor(0xFFB9A9D6);e=new Path();e.moveTo(w*.34f,h*.18f);e.lineTo(w*.40f,h*.02f);e.lineTo(w*.46f,h*.18f);e.close();c.drawPath(e,p);e=new Path();e.moveTo(w*.54f,h*.18f);e.lineTo(w*.60f,h*.02f);e.lineTo(w*.66f,h*.18f);e.close();c.drawPath(e,p);
 p.setColor(0xFF8D76B8);if(mood==2){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);c.drawArc(new RectF(w*.31f,h*.37f,w*.43f,h*.46f),10,160,false,p);c.drawArc(new RectF(w*.57f,h*.37f,w*.69f,h*.46f),10,160,false,p);p.setStyle(Paint.Style.FILL);}else{c.drawOval(new RectF(w*.31f,h*.37f,w*.43f,h*.48f),p);c.drawOval(new RectF(w*.57f,h*.37f,w*.69f,h*.48f),p);}
 p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);c.drawArc(new RectF(w*.43f,h*.47f,w*.57f,h*.56f),0,180,false,p);p.setStyle(Paint.Style.FILL);
 p.setColor(0xF7FFFFFF);c.drawRoundRect(new RectF(w*.08f,h*.90f,w*.92f,h*.99f),18,18,p);p.setColor(0xFF705C93);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(21);c.drawText(mood==0?"你好呀～":mood==1?"今天也要加油！":"眨眼～",w/2,h*.965f,p);c.restore();postInvalidateDelayed(40);}
}
