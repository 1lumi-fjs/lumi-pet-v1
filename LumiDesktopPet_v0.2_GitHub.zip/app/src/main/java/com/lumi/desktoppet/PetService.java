package com.lumi.desktoppet;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.provider.Settings;import android.view.*;import android.widget.Toast;
public class PetService extends Service{
 WindowManager wm;PetView pet;WindowManager.LayoutParams lp;
 public void onCreate(){super.onCreate();if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"请先开启悬浮窗权限",Toast.LENGTH_SHORT).show();stopSelf();return;}
 wm=(WindowManager)getSystemService(WINDOW_SERVICE);pet=new PetView(this);
 lp=new WindowManager.LayoutParams(280,360,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.START;lp.x=30;lp.y=300;
 pet.setOnTouchListener(new View.OnTouchListener(){float dx,dy;int sx,sy;long down;
 public boolean onTouch(View v,MotionEvent e){if(e.getAction()==0){dx=e.getRawX();dy=e.getRawY();sx=lp.x;sy=lp.y;down=System.currentTimeMillis();return true;}if(e.getAction()==2){lp.x=sx+(int)(e.getRawX()-dx);lp.y=sy+(int)(e.getRawY()-dy);wm.updateViewLayout(pet,lp);return true;}if(e.getAction()==1){if(System.currentTimeMillis()-down<250)pet.nextMood();return true;}return true;}});
 wm.addView(pet,lp);}
 public int onStartCommand(Intent i,int f,int id){return START_STICKY;} public void onDestroy(){if(wm!=null&&pet!=null)try{wm.removeView(pet);}catch(Exception e){}super.onDestroy();}public IBinder onBind(Intent i){return null;}
}
