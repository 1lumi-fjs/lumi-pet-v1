# 露米桌宠 v0.1

这是一个为 Android 手机制作的悬浮桌宠原型。

## 当前功能
- 悬浮窗
- 拖动角色
- 点击切换简单表情
- 白发、尖耳、双角、淡紫色眼睛、细长尾巴的二次元风格原型
- GitHub Actions 自动编译 APK

## 编译
在 GitHub 仓库的 Actions 页面运行 `Build Lumi Desktop Pet`。
成功后从 Artifacts 下载 APK。

## 下一步
可以继续加入：
- 正式露米立绘
- Live2D/动画
- 语音
- ChatGPT API
- 长期记忆
- 主动提醒
