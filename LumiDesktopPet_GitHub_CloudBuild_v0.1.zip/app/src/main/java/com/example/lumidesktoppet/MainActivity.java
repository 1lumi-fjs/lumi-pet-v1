package com.example.lumidesktoppet;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 60, 48, 48);

        TextView title = new TextView(this);
        title.setText("🎀 露米桌宠 v0.1");
        title.setTextSize(26);
        box.addView(title);

        TextView tip = new TextView(this);
        tip.setText("\n这是一个全新生成的 Android 桌宠原型。\n\n先开启“显示在其他应用上层”，再点击启动露米。");
        tip.setTextSize(17);
        box.addView(tip);

        Button permission = new Button(this);
        permission.setText("① 开启悬浮窗权限");
        permission.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });
        box.addView(permission);

        Button start = new Button(this);
        start.setText("② 启动露米");
        start.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) {
                startService(new Intent(this, PetService.class));
            } else {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        });
        box.addView(start);

        Button stop = new Button(this);
        stop.setText("③ 收起露米");
        stop.setOnClickListener(v -> stopService(new Intent(this, PetService.class)));
        box.addView(stop);

        setContentView(box);
    }
}
