package com.example.lumidesktoppet;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

public class PetView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int mood = 0;
    private long born = System.currentTimeMillis();

    public PetView(Context c) {
        super(c);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void nextMood() {
        mood = (mood + 1) % 3;
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        float t = (System.currentTimeMillis() - born) / 1000f;
        float bob = (float)Math.sin(t * 2.0) * 5f;

        // soft shadow
        p.setColor(0x22000000);
        c.drawOval(new RectF(w*.18f, h*.82f, w*.82f, h*.94f), p);

        // tail
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(10);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(0xFF8E7CC3);
        Path tail = new Path();
        tail.moveTo(w*.68f, h*.62f);
        tail.cubicTo(w*.92f, h*.58f, w*.95f, h*.78f, w*.78f, h*.78f);
        c.drawPath(tail, p);
        p.setStyle(Paint.Style.FILL);

        // dress
        p.setColor(0xFFEFEAF8);
        Path dress = new Path();
        dress.moveTo(w*.32f, h*.52f);
        dress.lineTo(w*.68f, h*.52f);
        dress.lineTo(w*.86f, h*.86f);
        dress.lineTo(w*.14f, h*.86f);
        dress.close();
        c.drawPath(dress, p);

        // hair
        p.setColor(Color.WHITE);
        c.drawRoundRect(new RectF(w*.20f, h*.18f, w*.80f, h*.65f), 55, 55, p);

        // ears
        p.setColor(0xFFEFEAF8);
        Path ear1 = new Path();
        ear1.moveTo(w*.23f, h*.28f); ear1.lineTo(w*.08f, h*.12f); ear1.lineTo(w*.20f, h*.40f); ear1.close();
        c.drawPath(ear1, p);
        Path ear2 = new Path();
        ear2.moveTo(w*.77f, h*.28f); ear2.lineTo(w*.92f, h*.12f); ear2.lineTo(w*.80f, h*.40f); ear2.close();
        c.drawPath(ear2, p);

        // horns
        p.setColor(0xFFB7A9D8);
        Path horn1 = new Path();
        horn1.moveTo(w*.34f, h*.18f); horn1.lineTo(w*.40f, h*.03f); horn1.lineTo(w*.45f, h*.18f); horn1.close();
        c.drawPath(horn1, p);
        Path horn2 = new Path();
        horn2.moveTo(w*.55f, h*.18f); horn2.lineTo(w*.60f, h*.03f); horn2.lineTo(w*.66f, h*.18f); horn2.close();
        c.drawPath(horn2, p);

        // eyes
        p.setColor(0xFF8E76B8);
        if (mood == 2) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5);
            c.drawArc(new RectF(w*.31f, h*.38f, w*.42f, h*.45f), 15, 150, false, p);
            c.drawArc(new RectF(w*.58f, h*.38f, w*.69f, h*.45f), 15, 150, false, p);
            p.setStyle(Paint.Style.FILL);
        } else {
            c.drawOval(new RectF(w*.32f, h*.37f, w*.42f, h*.47f), p);
            c.drawOval(new RectF(w*.58f, h*.37f, w*.68f, h*.47f), p);
        }

        // mouth
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4);
        if (mood == 1) {
            c.drawArc(new RectF(w*.43f, h*.47f, w*.57f, h*.56f), 15, 150, false, p);
        } else {
            c.drawArc(new RectF(w*.44f, h*.48f, w*.56f, h*.55f), 0, 180, false, p);
        }
        p.setStyle(Paint.Style.FILL);

        // label bubble
        p.setColor(0xF5FFFFFF);
        c.drawRoundRect(new RectF(w*.08f, h*.90f, w*.92f, h*.99f), 18, 18, p);
        p.setColor(0xFF6D5B8E);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(22);
        c.drawText(mood == 0 ? "你好呀～" : mood == 1 ? "嘿嘿～" : "眨眼！", w/2, h*.965f, p);

        postInvalidateDelayed(40);
    }
}
